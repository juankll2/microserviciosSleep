package ucuenca.microservice.suenio.sonido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SonidoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SonidoServiceApplication.class, args);
	}

}
