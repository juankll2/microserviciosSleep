package ucuenca.microservice.suenio.temperatura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TemperaturaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
